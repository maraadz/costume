<!DOCTYPE html>
<html>
<head>
  <title>Halaman Costumes Cosplay</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <style>
    /* CSS code for costume section */
    .costume-item {
      max-width: 800px;
      margin: 20px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      text-align: center;
    }

    .costume-item h3 {
      font-size: 18px;
      margin-bottom: 10px;
    }

    .costume-item p {
      color: #666;
      font-size: 14px;
      margin-bottom: 5px;
    }
  </style>
</head>
<body>
  <?php
  // Database connection
  include 'connection.php';

  $conn = new mysqli($servername, $username, $password, $database);

  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // Check if category_id is set
  if (isset($_GET['category_id'])) {
    $category_id = $_GET['category_id'];

    // Fetch category information
    $sql = "SELECT * FROM categories WHERE category_id = $category_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      $category = $result->fetch_assoc();
      echo '<h2>Halaman Costumes Cosplay</h2>';
      echo '<h3>Kategori: ' . $category['category_name'] . '</h3>';

      echo '<div class="costume-list">';
      // Fetch costumes from the selected category
      $sql = "SELECT * FROM costumes WHERE category_id = $category_id";
      $result = $conn->query($sql);

      // Display costumes
      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          echo '<div class="costume-item">';
          if (!empty($row['costume_name'])) {
            echo '<h3>' . $row['costume_name'] . '</h3>';
          } else {
            echo '<h3>Nama Costume Tidak Tersedia</h3>';
          }
          if (!empty($row['description'])) {
            echo '<p>' . $row['description'] . '</p>';
          } else {
            echo '<p>Deskripsi Costume Tidak Tersedia</p>';
          }
          if (!empty($row['price'])) {
            echo '<p>Harga: ' . $row['price'] . '</p>';
          } else {
            echo '<p>Harga Tidak Tersedia</p>';
          }
          echo '</div>';
        }
      } else {
        echo "<p>Tidak ada costume dalam kategori ini.</p>";
      }

      echo '</div>';
    } else {
      echo '<h3>Kategori Tidak Tersedia</h3>';
    }
  } else {
    echo "<p>Invalid category ID.</p>";
  }

  $conn->close();
  ?>
</body>
</html>
