<!DOCTYPE html>
<html>
<head>
  <title>Halaman Kategori Cosplay</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <script src="script.js"></script>
  <style>
    /* CSS code for category section */
    .category {
      max-width: 1200px;
      margin: 20px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      text-align: center;
    }

    .category h2 {
      font-size: 24px;
      margin-bottom: 10px;
    }

    .category-list {
      display: flex;
      justify-content: center;
      align-items: center;
      flex-wrap: wrap;
      margin-top: 20px;
    }

    .category-item {
      flex: 0 0 200px;
      margin: 10px;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 5px;
      text-align: center;
      cursor: pointer;
    }

    .category-item img {
      max-width: 150px;
      height: auto;
      margin-bottom: 10px;
    }

    .category-item h3 {
      font-size: 18px;
      margin-bottom: 5px;
    }

    .category-item p {
      color: #666;
      font-size: 14px;
    }
  </style>
</head>
<body>
  <h2>Halaman Kategori Cosplay</h2>
  <div class="category">
    <h2>Categories</h2>
    <div class="category-list">
      <?php
      // Database connection
      include 'connection.php';

      $conn = new mysqli($servername, $username, $password, $database);

      // Check connection
      if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
      }

      // Fetch categories from the database
      $sql = "SELECT * FROM categories";
      $result = $conn->query($sql);

      // Display categories
      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          echo '<div class="category-item">';
          if (isset($row['image'])) {
            echo '<img src="' . $row['image'] . '" alt="' . $row['category_name'] . '" class="category-image">';
          } else {
            echo '<img src="no_image.png" alt="No Image" class="category-image">';
          }
          if (isset($row['category_name'])) {
            echo '<h3>' . $row['category_name'] . '</h3>';
          } else {
            echo '<h3>Nama Kategori Tidak Tersedia</h3>';
          }
          if (isset($row['description'])) {
            echo '<p>' . $row['description'] . '</p>';
          } else {
            echo '<p>Deskripsi Kategori Tidak Tersedia</p>';
          }
          echo '<a href="customes.php?category_id=' . $row['category_id'] . '">Lihat Lebih Lanjut</a>';
          echo '</div>';
        }
      } else {
        echo "No categories found.";
      }
      ?>
      </div>
      
        </div>
      </body>
      </html>