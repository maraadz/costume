<!DOCTYPE html>
<html>
<head>
    <title>Riwayat Pesanan</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="script.js"></script>
</head>
<body>
    <h2>Riwayat Pesanan</h2>
    <!-- Order history content here -->
</body>
</html>
