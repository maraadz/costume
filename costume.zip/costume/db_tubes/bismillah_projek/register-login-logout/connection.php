<?php
$servername = "localhost";
$username = "root";
$password = "tiara124";
$database = "db_rentcosplay";
// Create connection
$conn = mysqli_connect ($servername, $username, $password, $database);
?>