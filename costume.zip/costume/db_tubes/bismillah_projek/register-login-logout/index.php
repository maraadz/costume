<?php
session_start();

// Cek apakah pengguna telah login dan memiliki peran admin
if (isset($_SESSION['user_id']) && $_SESSION['role_id'] == 1) {
  header('Location: admin.php');
  exit;
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Welcome to Shinju Rent Cosplay</title>
  <style>
    /* CSS code for navbar (added) */
    .navbar {
      background-color: #f2f2f2;
      overflow: hidden;
      text-align: center;
    }

    .navbar a {
      display: inline-block;
      color: #000;
      padding: 14px 16px;
      text-decoration: none;
      font-size: 18px;
      transition: background-color 0.3s;
    }

    .navbar a:hover {
      background-color: #e0e0e0;
    }

    /* Rest of the CSS code (updated) */
    body {
      font-family: Arial, sans-serif;
      background: linear-gradient(45deg, #ff9eeb, #a6dced, #cfa1ff);
      margin: 0;
      padding: 0;
    }

    .header {
      background: linear-gradient(to bottom, #333, #222);
      padding: 20px;
      color: #fff;
      text-align: center;
    }

    h1 {
      margin: 0;
      font-size: 36px;
      text-align: center;
      padding: 20px;
      color: #fff;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
    }

    .main {
      max-width: 1200px;
      margin: 20px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      text-align: center;
    }

    .anime-image {
      max-width: 400px;
      margin-bottom: 20px;
    }

    .anime-title {
      font-size: 24px;
      margin-bottom: 10px;
    }

    .anime-description {
      color: #666;
      margin-bottom: 20px;
    }

    .btn {
      background-color: #4caf50;
      color: #fff;
      padding: 10px 15px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
      text-decoration: none;
    }

    .btn:hover {
      background-color: #45a049;
    }

    .profile {
      position: fixed;
      top: 20px;
      right: 20px;
    }

    .profile img {
      width: 30px;
      height: 30px;
      border-radius: 50%;
      cursor: pointer;
    }

    .profile-dropdown {
      position: absolute;
      top: 40px;
      right: 0;
      background-color: #fff;
      padding: 10px;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      display: none;
    }

    .profile-dropdown a {
      display: block;
      padding: 5px 0;
      text-decoration: none;
      color: #333;
    }

    .profile-dropdown a:hover {
      background-color: #f2f2f2;
    }
  </style>
</head>
<body>
  <h1>Welcome to Shinju Rent Cosplay</h1>
  <div class="navbar">
    <a href="index.php">Home</a>
    <a href="category.php">Category</a>
    <a href="form_login.php">Order</a>
  </div>
</body>
</html>


  <div class="main">
    <img src="anime_image.GIF" alt="Anime Image" class="anime-image">
    <h2 class="anime-title">Rent Your Favorite Cosplay Outfits</h2>
    <p class="anime-description">Browse through our collection of high-quality cosplay costumes inspired by your favorite anime characters. Choose from a wide range of options and rent them for your next convention or event. Our costumes are meticulously crafted to ensure authenticity and provide you with the best cosplay experience.</p>
    <a href="#" class="btn">Browse Cosplay Collection</a>
</div>
<div class="profile">
  <img src="profile_icon.svg" alt="Profile Icon" class="profile-icon">
  <div class="profile-dropdown">
    <a href="form_login.php">Login</a>
    <a href="logout.php">Logout</a>
  </div>
</div>
<script>
  const profileIcon = document.querySelector('.profile-icon');
  const profileDropdown = document.querySelector('.profile-dropdown');

  profileIcon.addEventListener('click', () => {
    profileDropdown.style.display = profileDropdown.style.display === 'block' ? 'none' : 'block';
  });
</script>
</body>
</html>
