<?php
include "connection.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $email = $_POST["email"];
    $role = $_POST["role"];

    $errors = array();

    $checkQuery = "SELECT * FROM Users WHERE username = '$username'";
    $checkResult = mysqli_query($conn, $checkQuery);

    if (mysqli_num_rows($checkResult) > 0) {
        // Jika username sudah ada, tambahkan pesan kesalahan ke dalam array errors
        $errors[] = "Data pengguna sudah ada. Silakan login atau gunakan data yang berbeda.";
    }

    if (empty($errors)) {
        $roleQuery = "SELECT role_id FROM Roles WHERE role_name = '$role'";
        $roleResult = mysqli_query($conn, $roleQuery);
        $roleData = mysqli_fetch_assoc($roleResult);
        $roleId = $roleData['role_id'];

        $insert_query = "INSERT INTO Users (username, password, email, role_id) 
        VALUES ('$username', '$password', '$email', '$roleId')";

        if (mysqli_query($conn, $insert_query)) {
            echo "<script>";
            echo "alert('Anda berhasil terdaftar!');";
            echo "window.location.href = 'form_register.php';";
            echo "</script>";
        } else {
            echo "Error: " . $insert_query . "<br>" . mysqli_error($conn);
        }    
    } else {
        foreach ($errors as $error) {
            echo "<script>";
            echo "alert('$error');";
            echo "window.location.href = 'form_register.php';";
            echo "</script>";
        }
    }
}
?>
