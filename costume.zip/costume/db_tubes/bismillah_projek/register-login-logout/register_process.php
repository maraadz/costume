<?php
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = $_POST['username'];
  $password = $_POST['password'];
  $email = $_POST['email'];
  $role = $_POST['role'];

  $roleQuery = "SELECT role_id FROM roles WHERE role_name = '$role'";
  $roleResult = mysqli_query($conn, $roleQuery);
  $roleData = mysqli_fetch_assoc($roleResult);
  $roleId = $roleData['role_id'];

  $checkQuery = "SELECT * FROM users WHERE username = '$username'";
  $checkResult = mysqli_query($conn, $checkQuery);

  if (mysqli_num_rows($checkResult) > 0) {
    // Jika username sudah ada, tampilkan notifikasi dan arahkan ke halaman form register
    echo "<script>alert('Data pengguna sudah ada. Silakan login atau gunakan data yang berbeda.');</script>";
    echo "<script>window.location.href = 'form_register.php';</script>";
  } else {
    // Jika username belum ada, lanjutkan proses insert
    $query = "INSERT INTO users (username, password, email, role_id) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'sssi', $username, $password, $email, $roleId);
    mysqli_stmt_execute($stmt);
  
    header('Location: form_login.php');
    exit;
  }
}
?>
