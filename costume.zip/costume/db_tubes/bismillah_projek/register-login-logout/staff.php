<?php
session_start();

// Cek apakah pengguna telah login dan memiliki peran staff
if (!isset($_SESSION['user_id']) || $_SESSION['role_id'] != 2) {
  header('Location: index.php');
  exit;
}

// Memasukkan file koneksi database
include 'connection.php';

// Mendapatkan data kategori cosplay
$query = "SELECT * FROM categories";
$result = mysqli_query($conn, $query);
$categories = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Fungsi untuk menambahkan stok kostum
function addStock($costumeId, $quantity, $conn) {
  // Query untuk menambahkan stok kostum
  $query = "UPDATE costumes SET stock = stock + $quantity WHERE costume_id = $costumeId";
  mysqli_query($conn, $query);
}

// Memproses form tambah stok kostum
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['add_stock'])) {
    $costumeId = $_POST['costume_id'];
    $quantity = $_POST['quantity'];

    addStock($costumeId, $quantity, $conn);

    // Mengarahkan pengguna kembali ke halaman staff setelah menambahkan stok
    header('Location: staff.php');
    exit;
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Welcome to Shinju Rent Cosplay - Staff</title>
  <style>
    /* CSS code for navbar (added) */
    .navbar {
      background-color: #f2f2f2;
      overflow: hidden;
      text-align: center;
    }

    .navbar a {
      display: inline-block;
      color: #000;
      padding: 14px 16px;
      text-decoration: none;
      font-size: 18px;
      transition: background-color 0.3s;
    }

    .navbar a:hover {
      background-color: #e0e0e0;
    }

    /* Rest of the CSS code (updated) */
    body {
      font-family: Arial, sans-serif;
      background: linear-gradient(45deg, #ff9eeb, #a6dced, #cfa1ff);
      margin: 0;
      padding: 0;
    }

    .header {
      background: linear-gradient(to bottom, #333, #222);
      padding: 20px;
      color: #fff;
      text-align: center;
    }

    h1 {
      margin: 0;
      font-size: 36px;
      text-align: center;
      padding: 20px;
      color: #fff;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
    }

    .main {
      max-width: 1200px;
      margin: 20px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      text-align: center;
    }

    .admin-feature {
      display: flex;
      justify-content: center;
      align-items: center;
      margin-bottom: 20px;
    }

    .admin-feature a {
      display: block;
      width: 200px;
      height: 150px;
      background-color: #f2f2f2;
      color: #000;
      padding: 20px;
      text-decoration: none;
      font-size: 18px;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      transition: background-color 0.3s;
    }

    .admin-feature a:hover {
      background-color: #e0e0e0;
    }

    .container {
      margin-top: 20px;
    }

    .container h2 {
      text-align: center;
      margin-bottom: 20px;
    }

    .container h3 {
      margin-bottom: 10px;
    }

    .container table {
      width: 100%;
      margin-bottom: 20px;
    }

    .container th, .container td {
      padding: 8px;
      text-align: center;
    }

    .container table thead tr {
      background-color: #f2f2f2;
    }

    .container table tbody tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    .container form {
      margin-bottom: 20px;
    }

    .container form .form-group {
      margin-bottom: 10px;
    }
  </style>
</head>
<body>
  <h1>Welcome to Shinju Rent Cosplay - Staff</h1>
  <div class="navbar">
    <a href="index.php">Home</a>
    <a href="staff.php">Manage Categories</a>
    <a href="staff.php">Add Costume Stock</a>
    <a href="staff.php">Manage Customers</a>
    <a href="logout.php">Logout</a>
  </div>
  <div class="main">
    <div class="admin-feature">
      <a href="staff.php">Manage Categories</a>
      <a href="staff.php">Add Costume Stock</a>
      <a href="staff.php">Manage Customers</a>
    </div>
    <div class="container">
      <h2>Welcome, Staff</h2>

      <h3>Manage Categories</h3>
      <table class="table">
        <thead>
          <tr>
            <th>Category ID</th>
            <th>Category Name</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($categories as $category) { ?>
            <tr>
              <td><?php echo $category['category_id']; ?></td>
              <td><?php echo $category['category_name']; ?></td>
            </tr>
          <?php } ?>
        </tbody>
      </table>

      <h3>Add Costume Stock</h3>
      <form method="POST" action="staff.php">
        <div class="form-group">
          <label for="costume_id">Costume:</label>
          <select class="form-control" id="costume_id" name="costume_id" required>
            <?php foreach ($costumes as $costume) { ?>
              <option value="<?php echo $costume['costume_id']; ?>"><?php echo $costume['costume_name']; ?></option>
              <?php } ?>
          </select>
        </div>
        <div class="form-group">
          <label for="quantity">Quantity:</label>
          <input type="number" class="form-control" id="quantity" name="quantity" min="1" required>
        </div>
        <button type="submit" class="btn btn-primary" name="add_stock">Add Stock</button>
      </form>

      <h3>Manage Customers</h3>
      <!-- Add code to display customer data -->
    </div>
  </div>
</body>
</html>
