<!DOCTYPE html>
<html>
<head>
    <title>Halaman Pencarian</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="script.js"></script>
</head>
<body>
    <h2>Halaman Pencarian</h2>
    <!-- Search results content here -->
</body>
</html>
