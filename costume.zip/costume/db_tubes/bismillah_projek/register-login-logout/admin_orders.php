<?php
// Memeriksa apakah pengguna telah login sebagai admin
// session_start();
// if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] !== 1) {
//   header('Location: index.php');
//   exit;
// }

// Masukkan file koneksi database
include 'connection.php';

// Query untuk mendapatkan daftar pesanan
$query = "SELECT * FROM Orders";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin - Check Orders</title>
</head>
<body>
  <h1>Admin - Check Orders</h1>
  <a href="admin.php">Back to Home</a>
  <table>
    <tr>
      <th>Order ID</th>
      <th>Customer ID</th>
      <th>Costume ID</th>
      <th>Order Date</th>
      <th>Due Date</th>
      <th>Return Date</th>
      <th>User ID</th>
      <th>Status</th>
      <th>Action</th> <!-- Tambahkan kolom Action -->
    </tr>
    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
      <tr>
        <td><?php echo $row['order_id']; ?></td>
        <td><?php echo $row['customer_id']; ?></td>
        <td><?php echo $row['costume_id']; ?></td>
        <td><?php echo $row['order_date']; ?></td>
        <td><?php echo $row['tenggat_date']; ?></td>
        <td><?php echo $row['return_date']; ?></td>
        <td><?php echo $row['user_id']; ?></td>
        <td><?php echo $row['status']; ?></td>
        <td>
          <button onclick="editOrder(<?php echo $row['order_id']; ?>)">Edit</button>
          <a href="admin_orders.php?delete=<?php echo $row['order_id']; ?>" onclick="return confirm('Are you sure you want to delete this order?')">Delete</a>
        </td>
      </tr>
    <?php } ?>
  </table>

  <!-- Formulir Edit Pesanan (Modal) -->
  <div id="editModal" style="display: none;">
    <h2>Edit Order</h2>
    <form id="editForm" method="POST" action="">
      <input type="hidden" name="order_id" id="edit_order_id">
      <input type="text" name="edit_customer_id" id="edit_customer_id" placeholder="Customer ID">
      <input type="text" name="edit_costume_id" id="edit_costume_id" placeholder="Costume ID">
      <input type="text" name="edit_order_date" id="edit_order_date" placeholder="Order Date">
      <input type="text" name="edit_due_date" id="edit_due_date" placeholder="Due Date">
      <input type="text" name="edit_return_date" id="edit_return_date" placeholder="Return Date">
      <input type="text" name="edit_user_id" id="edit_user_id" placeholder="User ID">
      <input type="text" name="edit_status" id="edit_status" placeholder="Status">
      <button type="submit" name="edit_submit">Save</button>
    </form>
  </div>

  <script>
    // Fungsi untuk mengisi nilai dalam form edit pesanan
    function editOrder(orderId) {
      // Mengambil elemen form
      var editForm = document.getElementById("editForm");

      // Mengambil elemen input dalam form
      var editOrderId = document.getElementById("edit_order_id");
      var editCustomerId = document.getElementById("edit_customer_id");
      var editCostumeId = document.getElementById("edit_costume_id");
      var editOrderDate = document.getElementById("edit_order_date");
      var editDueDate = document.getElementById("edit_due_date");
      var editReturnDate = document.getElementById("edit_return_date");
      var editUserId = document.getElementById("edit_user_id");
      var editStatus = document.getElementById("edit_status");

      // Mengisi nilai input dengan data dari database
      editOrderId.value = orderId;
      editCustomerId.value = "<?php echo $row['customer_id']; ?>";
      editCostumeId.value = "<?php echo $row['costume_id']; ?>";
      editOrderDate.value = "<?php echo $row['order_date']; ?>";
      editDueDate.value = "<?php echo $row['tenggat_date']; ?>";
      editReturnDate.value = "<?php echo $row['return_date']; ?>";
      editUserId.value = "<?php echo $row['user_id']; ?>";
      editStatus.value = "<?php echo $row['status']; ?>";

      // Menampilkan modal edit
      document.getElementById("editModal").style.display = "block";
    }
  </script>
</body>
</html>
