<?php
// Memeriksa apakah pengguna telah login sebagai admin
session_start();
// if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] !== 1) {
//   header('Location: index.php');
//   exit;
//}

// Masukkan file koneksi database
include 'connection.php';

// Variabel untuk menyimpan pesan error
$error = '';

// Pengecekan jika formulir tambah alamat dikirimkan
if (isset($_POST["submit"])) {
  // Ambil nilai dari form
  $fullName = $_POST['full_name'];
  $address = $_POST['address'];
  $city = $_POST['city'];
  $postalCode = $_POST['postal_code'];

  // Validasi form
  if (empty($fullName) || empty($address) || empty($city) || empty($postalCode)) {
    $error = 'All fields are required.';
  } else {
    // Query untuk menambahkan data ke database
    $insertQuery = "INSERT INTO addresses (full_name, address, city, postal_code) VALUES ('$fullName', '$address', '$city', '$postalCode')";
    if (mysqli_query($conn, $insertQuery)) {
      // Redirect ke halaman admin setelah data berhasil ditambahkan
      header('Location: addresses.php');
      exit;
    } else {
      $error = 'Error adding address: ' . mysqli_error($conn);
    }
  }
}

// Pengecekan jika formulir edit alamat dikirimkan
if (isset($_POST["edit_submit"])) {
  // Ambil nilai dari form
  $addressID = $_POST['address_id'];
  $fullName = $_POST['edit_full_name'];
  $address = $_POST['edit_address'];
  $city = $_POST['edit_city'];
  $postalCode = $_POST['edit_postal_code'];

  // Validasi form
  if (empty($fullName) || empty($address) || empty($city) || empty($postalCode)) {
    $error = 'All fields are required.';
  } else {
    // Query untuk update data alamat berdasarkan ID
    $updateQuery = "UPDATE addresses SET full_name='$fullName', address='$address', city='$city', postal_code='$postalCode' WHERE address_id='$addressID'";
    if (mysqli_query($conn, $updateQuery)) {
      // Redirect ke halaman admin setelah data berhasil diupdate
      header('Location: addresses.php');
      exit;
    } else {
      $error = 'Error updating address: ' . mysqli_error($conn);
    }
  }
}

// Pengecekan jika tombol "Delete" diklik
if (isset($_GET["delete"])) {
  // Ambil ID alamat yang akan dihapus
  $addressID = $_GET["delete"];

  // Query untuk mendapatkan nama alamat
  $selectQuery = "SELECT full_name FROM addresses WHERE address_id='$addressID'";
  $result = mysqli_query($conn, $selectQuery);
  $row = mysqli_fetch_assoc($result);
  $fullName = $row['full_name'];

  // Tampilkan modal konfirmasi penghapusan
  echo "
  <script>
    var deleteConfirmation = confirm('Are you sure you want to delete the address \"$fullName\"?');
    if (deleteConfirmation) {
      window.location.href = 'addresses.php?deleteConfirmed=$addressID';
    } else {
      window.location.href = 'addresses.php';
    }
  </script>
  ";
  exit;
}

// Pengecekan jika konfirmasi penghapusan dilakukan
if (isset($_GET["deleteConfirmed"])) {
  // Ambil ID alamat yang akan dihapus
  $addressID = $_GET["deleteConfirmed"];

  // Query untuk hapus data alamat berdasarkan ID
  $deleteQuery = "DELETE FROM addresses WHERE address_id = '$addressID';";
  if (mysqli_query($conn, $deleteQuery)) {
    // Redirect ke halaman admin setelah data berhasil dihapus
    header('Location: addresses.php');
    exit;
  } else {
    $error = 'Error deleting address: ' . mysqli_error($conn);
  }
}

// Query untuk mendapatkan daftar alamat
$query = "SELECT * FROM addresses";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin - Check Addresses</title>
  <!-- Tambahkan link CSS Bootstrap -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
  <div class="container">
    <h1 class="mt-4">Admin - Check Addresses</h1>
    <a href="admin.php" class="btn btn-primary mb-4">Back to Home</a>
    <table class="table">
      <thead>
        <tr>
          <th>Address ID</th>
          <th>Full Name</th>
          <th>Address</th>
          <th>City</th>
          <th>Postal Code</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
          <tr>
            <td><?php echo $row['address_id']; ?></td>
            <td><?php echo $row['full_name']; ?></td>
            <td><?php echo $row['address']; ?></td>
            <td><?php echo $row['city']; ?></td>
            <td><?php echo $row['postal_code']; ?></td>
            <td>
              <button class="btn btn-primary" data-toggle="modal" data-target="#editAddressModal<?php echo $row['address_id']; ?>">Edit</button>
              <button class="btn btn-danger" data-toggle="modal" data-target="#deleteAddressModal<?php echo $row['address_id']; ?>">Delete</button>
            </td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
    <button class="btn btn-success" data-toggle="modal" data-target="#addAddressModal">Add Address</button>
  </div>

  <!-- Modal untuk form edit alamat -->
  <?php mysqli_data_seek($result, 0); // Mengembalikan kursor ke awal ?>
  <?php while ($row = mysqli_fetch_assoc($result)) { ?>
    <div class="modal fade" id="editAddressModal<?php echo $row['address_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="editAddressModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="editAddressModalLabel">Edit Address</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form method="POST" action="">
              <input type="hidden" name="address_id" value="<?php echo $row['address_id']; ?>">
              <div class="form-group">
                <label for="editFullName">Full Name</label>
                <input type="text" class="form-control" id="editFullName" name="edit_full_name" value="<?php echo $row['full_name']; ?>" required>
              </div>
              <div class="form-group">
                <label for="editAddress">Address</label>
                <input type="text" class="form-control" id="editAddress" name="edit_address" value="<?php echo $row['address']; ?>" required>
              </div>
              <div class="form-group">
                <label for="editCity">City</label>
                <input type="text" class="form-control" id="editCity" name="edit_city" value="<?php echo $row['city']; ?>" required>
              </div>
              <div class="form-group">
                <label for="editPostalCode">Postal Code</label>
                <input type="text" class="form-control" id="editPostalCode" name="edit_postal_code" value="<?php echo $row['postal_code']; ?>" required>
              </div>
              <button type="submit" class="btn btn-primary" name="edit_submit">Submit</button>
            </form>
            <?php if ($error) { ?>
              <div class="alert alert-danger mt-3"><?php echo $error; ?></div>
            <?php } ?>
          </div>
        </div>
      </div>
    </div>
  <?php } ?>

  <!-- Modal untuk konfirmasi penghapusan alamat -->
  <?php mysqli_data_seek($result, 0); // Mengembalikan kursor ke awal ?>
  <?php while ($row = mysqli_fetch_assoc($result)) { ?>
    <div class="modal fade" id="deleteAddressModal<?php echo $row['address_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="deleteAddressModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="deleteAddressModalLabel">Delete Address</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form action="" method="POST">
              <input type="hidden" name="address_id" value="<?php echo $row['address_id']; ?>">
              <p>Are you sure you want to delete the address "<?php echo $row['address']; ?>"?</p>
              <button type="submit" class="btn btn-danger" name="DELETE">Delete</button>
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  <?php } ?>

  <!-- Modal untuk form tambah alamat -->
  <div class="modal fade" id="addAddressModal" tabindex="-1" role="dialog" aria-labelledby="addAddressModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="addAddressModalLabel">Add Address</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form method="POST" action="">
            <div class="form-group">
              <label for="fullName">Full Name</label>
              <input type="text" class="form-control" id="fullName" name="full_name" required>
            </div>
            <div class="form-group">
              <label for="address">Address</label>
              <input type="text" class="form-control" id="address" name="address" required>
            </div>
            <div class="form-group">
              <label for="city">City</label>
              <input type="text" class="form-control" id="city" name="city" required>
            </div>
            <div class="form-group">
              <label for="postalCode">Postal Code</label>
              <input type="text" class="form-control" id="postalCode" name="postal_code" required>
            </div>
            <button type="submit" class="btn btn-primary" name="submit">Submit</button>
          </form>
          <?php if ($error) { ?>
            <div class="alert alert-danger mt-3"><?php echo $error; ?></div>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Tambahkan script JavaScript Bootstrap -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
