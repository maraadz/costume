<?php
session_start();
include "connection.php";

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
  header('Location: form_login.php');
  exit;
}

// Mendapatkan data pengguna berdasarkan user_id dari session
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE user_id = $user_id";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

// Menghandle perubahan password
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $new_password = $_POST["new_password"];

    // Update password pengguna di database
    $update_query = "UPDATE users SET password = '$new_password' WHERE user_id = $user_id";
    if (mysqli_query($conn, $update_query)) {
        // Menghapus data session dan mengarahkan pengguna ke halaman login
        session_unset();
        session_destroy();
        header('Location: form_login.php');
        exit;
    } else {
        echo "Error: " . $update_query . "<br>" . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Profile</title>
  <style>
    /* Styling untuk profile penyewa */
    .profile-container {
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
      background-color: #f8f8f8;
      border: 1px solid #ddd;
      border-radius: 5px;
    }

    .profile-container h5 {
      color: #333;
      font-size: 18px;
      margin-bottom: 15px;
    }

    .profile-container .row {
      margin-bottom: 10px;
    }

    .profile-container .label {
      font-weight: bold;
      color: #555;
    }

    .profile-container .btn-save {
      background-color: #4CAF50;
      color: white;
      border: none;
      padding: 8px 20px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 16px;
      margin-top: 10px;
      cursor: pointer;
      border-radius: 5px;
      transition: background-color 0.3s;
    }

    .profile-container .btn-save:hover {
      background-color: #45a049;
    }

    /* Animasi untuk profile penyewa */
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    .profile-container {
      animation: fadeIn 0.5s ease-in-out;
    }

    .btn-back {
  background-color: #f44336;
  color: white;
  padding: 8px 16px;
  border-radius: 4px;
  text-decoration: none;
}

.btn-back:hover {
  background-color: #d32f2f;
}

  </style>
</head>
<body>
  <div class="profile-container">
    <h5>Profile Details</h5>

    <div class="row">
      <div class="label">Username:</div>
      <div><?php echo $user['username']; ?></div>
    </div>

    <div class="row">
      <div class="label">Email:</div>
      <div><?php echo $user['email']; ?></div>
    </div>
    <div class="row">
  <div class="label">Role:</div>
  <div><?php echo $user['role_id']; ?></div>
</div>

<?php if ($user['role_id'] == 3) { // Hanya menampilkan form edit password untuk pengguna penyewa ?>
  <form method="POST" action="">
    <div class="row">
      <div class="label">New Password:</div>
      <div>
        <input type="password" name="new_password" required>
      </div>
    </div>

    <div class="row">
      <div class="label"></div>
      <div>
        <input type="submit" value="Save" class="btn-save">
      </div>
    </div>

    <div class="row">
  <div>
    <a href="penyewa.php" class="btn-back">Back</a>
  </div>
</div>

  </form>
<?php } ?>
</div>
</body>
</html>
