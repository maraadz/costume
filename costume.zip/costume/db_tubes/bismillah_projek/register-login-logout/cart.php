<!DOCTYPE html>
<html>
<head>
    <title>Halaman Keranjang</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="script.js"></script>
</head>
<body>
    <h2>Halaman Keranjang</h2>
    <!-- Cart content here -->
    <button onclick="goToPaymentPage()">Lanjut ke Pembayaran</button>
</body>
</html>
