<?php
session_start();
include "connection.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Order Cosplay</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="script.js"></script>
</head>
<body>
<?php
// Cek apakah pengguna sudah login atau belum
// Jika belum, alihkan ke halaman login
session_start();
if (!isset($_SESSION['user_id'])) {
  header("Location: form_login.php");
  exit();
}

// Cek apakah ada category_id yang dikirimkan
// Jika tidak, alihkan kembali ke halaman customes
if (!isset($_GET['category_id'])) {
  header("Location: customes.php");
  exit();
}

// Ambil category_id dari parameter URL
$category_id = $_GET['category_id'];

// Ambil informasi custom cosplay berdasarkan category_id (asumsikan tabel customes bernama "customes")
$customesSql = "SELECT * FROM customes WHERE category_id = $category_id";
$customesResult = $conn->query($customesSql);

if ($customesResult->num_rows > 0) {
  $customesRow = $customesResult->fetch_assoc();
  $customesId = $customesRow['customes_id'];
  $customesName = $customesRow['customes_name'];
  $customesPrice = $customesRow['customes_price'];
  $customesImage = $customesRow['customes_image'];

  // Tampilkan form order
  echo '<h2>Order Cosplay: ' . $customesName . '</h2>';
  echo '<div class="order-details">';
  echo '<img src="' . $customesImage . '" alt="' . $customesName . '" class="customes-image">';
  echo '<h3>Harga: $' . $customesPrice . '</h3>';
  echo '<form action="payment.php" method="POST">';
  echo '<label for="address">Alamat:</label>';
  echo '<input type="text" name="address" id="address">';
  echo '<input type="hidden" name="customes_id" value="' . $customesId . '">';
  echo '<input type="hidden" name="customes_name" value="' . $customesName . '">';
  echo '<input type="hidden" name="customes_price" value="' . $customesPrice . '">';
  echo '<input type="submit" name="submit" value="Order Now">';
  echo '</form>';
  echo '<a href="customes.php">Cancel</a>';
  echo '</div>'; // Tutup div order-details
} else {
  echo '<p>Custom cosplay tidak ditemukan.</p>';
}

// Tutup koneksi database
$conn->close();
?>
</body>
</html>
