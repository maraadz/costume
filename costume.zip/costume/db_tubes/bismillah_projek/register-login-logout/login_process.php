<?php
// Memulai session
session_start();

// Memasukkan file koneksi database
include 'connection.php';

// Mendapatkan data dari form login
$username = $_POST['username'];
$password = $_POST['password'];

// Melakukan query untuk mendapatkan data pengguna berdasarkan username
$query = "SELECT * FROM users WHERE username = '$username'";
$result = mysqli_query($conn, $query);

// Mengecek apakah query berhasil dijalankan dan mendapatkan hasil
if ($result && mysqli_num_rows($result) > 0) {
  // Mendapatkan data pengguna dari hasil query
  $user = mysqli_fetch_assoc($result);

  // Memeriksa kecocokan password
  if ($user['password'] == $password) {
    // Login berhasil, menyimpan data pengguna ke dalam session
    $_SESSION['user_id'] = $user['user_id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['role_id'] = $user['role_id'];

    // Mengarahkan pengguna ke halaman sesuai peran
    if ($user['role_id'] == 1) {
      // Jika peran adalah admin, arahkan ke halaman admin.php
      header('Location: admin.php');
      exit;
    } elseif ($user['role_id'] == 2) {
      // Jika peran adalah staff, arahkan ke halaman staff.php
      header('Location: staff.php');
      exit;
    } elseif ($user['role_id'] == 3) {
      // Jika peran adalah penyewa, arahkan ke halaman penyewa.php
      header('Location: penyewa.php');
      exit;
    }
  }
}

// Jika login gagal, kembalikan ke halaman login dengan pesan error
$_SESSION['login_error'] = 'Invalid username or password';
header('Location: form_login.php');
exit;
?>
