<?php
// Memeriksa apakah pengguna telah login sebagai admin
session_start();
// if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] !== 1) {
//   header('Location: index.php');
//   exit;
//}

// Masukkan file koneksi database
include 'connection.php';

// Variabel untuk menyimpan pesan error
$error = '';

// Pengecekan jika formulir tambah kategori dikirimkan
if (isset($_POST["submit"])) {
  // Ambil nilai dari form
  $categoryName = $_POST['category_name'];

  // Validasi form
  if (empty($categoryName)) {
    $error = 'Category Name is required.';
  } else {
    // Query untuk menambahkan data ke database
    $insertQuery = "INSERT INTO categories (category_name) VALUES ('$categoryName')";
    if (mysqli_query($conn, $insertQuery)) {
      // Redirect ke halaman admin setelah data berhasil ditambahkan
      header('Location: admin.php');
      exit;
    } else {
      $error = 'Error adding category: ' . mysqli_error($conn);
    }
  }
}

// Pengecekan jika formulir edit kategori dikirimkan
if (isset($_POST["edit_submit"])) {
  // Ambil nilai dari form
  $categoryID = $_POST['category_id'];
  $categoryName = $_POST['edit_category_name'];

  // Validasi form
  if (empty($categoryName)) {
    $error = 'Category Name is required.';
  } else {
    // Query untuk update data kategori berdasarkan ID
    $updateQuery = "UPDATE categories SET category_name='$categoryName' WHERE category_id='$categoryID'";
    if (mysqli_query($conn, $updateQuery)) {
      // Redirect ke halaman admin setelah data berhasil diupdate
      header('Location: admin.php');
      exit;
    } else {
      $error = 'Error updating category: ' . mysqli_error($conn);
    }
  }
}

// Pengecekan jika tombol "Delete" diklik
if (isset($_GET["delete"])) {
  // Ambil ID kategori yang akan dihapus
  $categoryID = $_GET["delete"];

  // Query untuk mendapatkan nama kategori
  $selectQuery = "SELECT category_name FROM categories WHERE category_id='$categoryID'";
  $result = mysqli_query($conn, $selectQuery);
  $row = mysqli_fetch_assoc($result);
  $categoryName = $row['category_name'];

  // Tampilkan modal konfirmasi penghapusan
  echo "
  <script>
    var deleteConfirmation = confirm('Are you sure you want to delete the category \"$categoryName\"?');
    if (deleteConfirmation) {
      window.location.href = 'admin.php?deleteConfirmed=$categoryID';
    } else {
      window.location.href = 'admin.php';
    }
  </script>
  ";
  exit;
}

// Pengecekan jika konfirmasi penghapusan dilakukan
if (isset($_POST["DELETE"])) {
  // Ambil ID kategori yang akan dihapus
  $categoryID = $_POST['category_id'];

  // Query untuk update data kategori berdasarkan ID
   
  $deleteQuery = "DELETE FROM categories WHERE category_id = '$categoryID';";
  if (mysqli_query($conn, $deleteQuery)) {
    // Redirect ke halaman admin setelah data berhasil dihapus
    header('Location: admin.php');
    exit;
  } else {
    $error = 'Error deleting category: ' . mysqli_error($conn);
  }
}

// Query untuk mendapatkan daftar kategori
$query = "SELECT * FROM categories";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin - Check Categories</title>
  <!-- Tambahkan link CSS Bootstrap -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
  <div class="container">
    <h1 class="mt-4">Admin - Check Categories</h1>
    <a href="admin.php" class="btn btn-primary mb-4">Back to Home</a>
    <table class="table">
      <thead>
        <tr>
          <th>Category ID</th>
          <th>Category Name</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
          <tr>
            <td><?php echo $row['category_id']; ?></td>
            <td><?php echo $row['category_name']; ?></td>
            <td>
              <button class="btn btn-primary" data-toggle="modal" data-target="#editCategoryModal<?php echo $row['category_id']; ?>">Edit</button>
              <button class="btn btn-danger" data-toggle="modal" data-target="#deleteCategoryModal<?php echo $row['category_id']; ?>">Delete</button>
            </td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
    <button class="btn btn-success" data-toggle="modal" data-target="#addCategoryModal">Add Category</button>
  </div>

  <!-- Modal untuk form edit kategori -->
  <?php mysqli_data_seek($result, 0); // Mengembalikan kursor ke awal ?>
  <?php while ($row = mysqli_fetch_assoc($result)) { ?>
    <div class="modal fade" id="editCategoryModal<?php echo $row['category_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="editCategoryModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="editCategoryModalLabel">Edit Category</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form method="POST" action="">
              <input type="hidden" name="category_id" value="<?php echo $row['category_id']; ?>">
              <div class="form-group">
                <label for="editCategoryName">Category Name</label>
                <input type="text" class="form-control" id="editCategoryName" name="edit_category_name" value="<?php echo $row['category_name']; ?>" required>
              </div>
              <button type="submit" class="btn btn-primary" name="edit_submit">Submit</button>
            </form>
            <?php if ($error) { ?>
              <div class="alert alert-danger mt-3"><?php echo $error; ?></div>
            <?php } ?>
          </div>
        </div>
      </div>
    </div>
  <?php } ?>

  <!-- Modal untuk konfirmasi penghapusan kategori -->
  <?php mysqli_data_seek($result, 0); // Mengembalikan kursor ke awal ?>
  <?php while ($row = mysqli_fetch_assoc($result)) { ?>
    <div class="modal fade" id="deleteCategoryModal<?php echo $row['category_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="deleteCategoryModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="deleteCategoryModalLabel">Delete Category</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form action="" method="POST">
              <input type="hidden" name="category_id" value="<?php echo $row['category_id']; ?>">
              <p>Are you sure you want to delete the category "<?php echo $row['category_name']; ?>"?</p>
              <button type="submit" class="btn btn-danger" name="DELETE">Delete</button>
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  <?php } ?>

  <!-- Modal untuk form tambah kategori -->
  <div class="modal fade" id="addCategoryModal" tabindex="-1" role="dialog" aria-labelledby="addCategoryModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="addCategoryModalLabel">Add Category</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form method="POST" action="">
            <div class="form-group">
              <label for="categoryName">Category Name</label>
              <input type="text" class="form-control" id="categoryName" name="category_name" required>
            </div>
            <button type="submit" class="btn btn-primary" name="submit">Submit</button>
          </form>
          <?php if ($error) { ?>
            <div class="alert alert-danger mt-3"><?php echo $error; ?></div>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Tambahkan skrip JS Bootstrap (jQuery dan Popper.js) -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
