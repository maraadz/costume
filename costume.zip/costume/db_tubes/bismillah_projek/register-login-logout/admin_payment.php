<?php
// Memeriksa apakah pengguna telah login sebagai admin
session_start();
// if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] !== 1) {
//   header('Location: index.php');
//   exit;
}

// Masukkan file koneksi database
include 'connection.php';

// Query untuk mendapatkan daftar pembayaran
$query = "SELECT * FROM Payments";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin - Check Payments</title>
</head>
<body>
  <h1>Admin - Check Payments</h1>
  <a href="admin.php">Back to Home</a>
  <table>
    <tr>
      <th>Payment ID</th>
      <th>Order ID</th>
      <th>Payment Date</th>
      <th>Amount</th>
      <th>Address ID</th>
      <th>Status</th>
      <th>Action</th>
    </tr>
    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
      <tr>
        <td><?php echo $row['payment_id']; ?></td>
        <td><?php echo $row['order_id']; ?></td>
        <td><?php echo $row['payment_date']; ?></td>
        <td><?php echo $row['amount']; ?></td>
        <td><?php echo $row['address_id']; ?></td>
        <td><?php echo $row['status']; ?></td>
        <td>
          <button onclick="editPayment(<?php echo $row['payment_id']; ?>)">Edit</button>
          <a href="admin_payment.php?delete=<?php echo $row['payment_id']; ?>" onclick="return confirm('Are you sure you want to delete this payment?')">Delete</a>
        </td>
      </tr>
    <?php } ?>
  </table>

  <!-- Formulir Edit Pembayaran (Modal) -->
  <div id="editModal" style="display: none;">
    <h2>Edit Payment</h2>
    <form id="editForm" method="POST" action="">
      <input type="hidden" name="payment_id" id="edit_payment_id">
      <input type="text" name="edit_order_id" id="edit_order_id" placeholder="Order ID">
      <input type="text" name="edit_payment_date" id="edit_payment_date" placeholder="Payment Date">
      <input type="text" name="edit_amount" id="edit_amount" placeholder="Amount">
      <input type="text" name="edit_address_id" id="edit_address_id" placeholder="Address ID">
      <input type="text" name="edit_status" id="edit_status" placeholder="Status">
      <button type="submit" name="edit_submit">Save</button>
    </form>
  </div>

  <script>
    // Fungsi untuk mengisi nilai dalam form edit pembayaran
    function editPayment(paymentId) {
      // Mengambil elemen form
      var editForm = document.getElementById("editForm");

      // Mengambil elemen input dalam form
      var editPaymentId = document.getElementById("edit_payment_id");
      var editOrderId = document.getElementById("edit_order_id");
      var editPaymentDate = document.getElementById("edit_payment_date");
      var editAmount = document.getElementById("edit_amount");
      var editAddressId = document.getElementById("edit_address_id");
      var editStatus = document.getElementById("edit_status");

      // Mengisi nilai dalam form dengan data pembayaran yang dipilih
      editPaymentId.value = paymentId;
      editOrderId.value = "<?php echo $row['order_id']; ?>";
      editPaymentDate.value = "<?php echo $row['payment_date']; ?>";
      editAmount.value = "<?php echo $row['amount']; ?>";
      editAddressId.value = "<?php echo $row['address_id']; ?>";
      editStatus.value = "<?php echo $row['status']; ?>";

      // Menampilkan modal edit
      document.getElementById("editModal").style.display = "block";
    }
  </script>
</body>
</html>
