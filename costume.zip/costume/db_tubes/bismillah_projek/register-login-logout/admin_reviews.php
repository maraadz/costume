<?php
// Memeriksa apakah pengguna telah login sebagai admin
session_start();
// if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] !== 1) {
//   header('Location: index.php');
//   exit;
}

// Memasukkan file koneksi database
include 'connection.php';

// Query untuk mendapatkan daftar ulasan
$query = "SELECT * FROM Reviews";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin - Check Reviews</title>
</head>
<body>
  <h1>Admin - Check Reviews</h1>
  <a href="admin.php">Back to Home</a>
  <table>
    <tr>
      <th>Review ID</th>
      <th>Customer ID</th>
      <th>Costume ID</th>
      <th>Rating</th>
      <th>Comment</th>
      <th>Action</th>
    </tr>
    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
      <tr>
        <td><?php echo $row['review_id']; ?></td>
        <td><?php echo $row['user_id']; ?></td>
        <td><?php echo $row['costume_id']; ?></td>
        <td><?php echo $row['rating']; ?></td>
        <td><?php echo $row['review']; ?></td>
        <td>
          <button onclick="editReview(<?php echo $row['review_id']; ?>)">Edit</button>
          <a href="admin_reviews.php?delete=<?php echo $row['review_id']; ?>" onclick="return confirm('Are you sure you want to delete this review?')">Delete</a>
        </td>
      </tr>
    <?php } ?>
  </table>

  <!-- Formulir Edit Ulasan (Modal) -->
  <div id="editModal" style="display: none;">
    <h2>Edit Review</h2>
    <form id="editForm" method="POST" action="">
      <input type="hidden" name="review_id" id="edit_review_id">
      <input type="text" name="edit_user_id" id="edit_user_id" placeholder="User ID">
      <input type="text" name="edit_costume_id" id="edit_costume_id" placeholder="Costume ID">
      <input type="text" name="edit_rating" id="edit_rating" placeholder="Rating">
      <textarea name="edit_review" id="edit_review" placeholder="Review"></textarea>
      <button type="submit" name="edit_submit">Save</button>
    </form>
  </div>

  <script>
    // Fungsi untuk mengisi nilai dalam form edit ulasan
    function editReview(reviewId) {
      // Mengambil elemen form
      var editForm = document.getElementById("editForm");

      // Mengambil elemen input dalam form
      var editReviewId = document.getElementById("edit_review_id");
      var editUserId = document.getElementById("edit_user_id");
      var editCostumeId = document.getElementById("edit_costume_id");
      var editRating = document.getElementById("edit_rating");
      var editReview = document.getElementById("edit_review");

      // Mengisi nilai dalam form dengan data ulasan yang dipilih
      editReviewId.value = reviewId;
      editUserId.value = "<?php echo $row['user_id']; ?>";
      editCostumeId.value = "<?php echo $row['costume_id']; ?>";
      editRating.value = "<?php echo $row['rating']; ?>";
      editReview.value = "<?php echo $row['review']; ?>";

      // Menampilkan modal edit
      document.getElementById("editModal").style.display = "block";
    }
  </script>
</body>
</html>
