// JavaScript code for page navigation
function goToHomePage() {
    window.location.href = "index.php";
}

function goToCategoryPage() {
    window.location.href = "category.php";
}

function goToCosplayDetailPage() {
    window.location.href = "cosplay_detail.php";
}

// Add more functions for other pages...
