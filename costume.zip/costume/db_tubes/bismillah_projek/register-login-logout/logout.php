<?php
// Memulai session
session_start();

// Menghapus semua data session
session_unset();
session_destroy();

// Mengarahkan pengguna ke halaman register
header('Location: form_login.php');
exit;
?>
