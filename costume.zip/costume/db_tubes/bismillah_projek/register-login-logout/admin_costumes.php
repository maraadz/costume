<?php
// Memeriksa apakah pengguna telah login sebagai admin
session_start();
// if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] !== 1) {
//   header('Location: index.php');
//   exit;
//}

// Masukkan file koneksi database
include 'connection.php';

// Query untuk mendapatkan daftar kostum
$query = "SELECT * FROM costumes";
$result = mysqli_query($conn, $query);

// Proses simpan data kostum baru
if (isset($_POST['add_submit'])) {
  $categoryID = $_POST['category_id'];
  $costumeName = $_POST['costume_name'];
  $description = $_POST['description'];
  $price = $_POST['price'];
  $stok = $_POST['stok'];

  $insertQuery = "INSERT INTO costumes (category_id, costume_name, description, price, stok) 
                  VALUES ('$categoryID', '$costumeName', '$description', '$price', '$stok')";
  mysqli_query($conn, $insertQuery);
  header("Location: admin_customes.php");
  exit();
}

// Proses edit data kostum
if (isset($_POST['edit_submit'])) {
  $costumeID = $_POST['costume_id'];
  $categoryID = $_POST['edit_category_id'];
  $costumeName = $_POST['edit_costume_name'];
  $description = $_POST['edit_description'];
  $price = $_POST['edit_price'];
  $stok = $_POST['edit_stok'];

  $updateQuery = "UPDATE Costumes SET category_id='$categoryID', costume_name='$costumeName', 
                  description='$description', price='$price', stok='$stok' WHERE costume_id='$costumeID'";
  mysqli_query($conn, $updateQuery);
  header("Location: customes.php");
  exit();
}

// Proses hapus data kostum
if (isset($_GET['delete'])) {
  $costumeID = $_GET['delete'];

  $deleteQuery = "DELETE FROM Costumes WHERE costume_id='$costumeID'";
  mysqli_query($conn, $deleteQuery);
  header("Location: customes.php");
  exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin - Check Costumes</title>
</head>
<body>
  <h1>Admin - Check Costumes</h1>
  <a href="admin.php">Back to Home</a>

  <table>
    <tr>
      <th>Costume ID</th>
      <th>Category</th>
      <th>Costume Name</th>
      <th>Description</th>
      <th>Price</th>
      <th>Stok</th>
      <th>Action</th> <!-- Tambahkan kolom Action -->
    </tr>
    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
      <tr>
        <td><?php echo $row['costume_id']; ?></td>
        <td><?php echo $row['category_id']; ?></td>
        <td><?php echo $row['costume_name']; ?></td>
        <td><?php echo $row['description']; ?></td>
        <td><?php echo $row['price']; ?></td>
        <td><?php echo $row['stok']; ?></td>
        <td>
          <button onclick="editCostume(<?php echo $row['costume_id']; ?>)">Edit</button>
          <a href="customes.php?delete=<?php echo $row['costume_id']; ?>" onclick="return confirm('Are you sure you want to delete this costume?')">Delete</a>
        </td>
      </tr>
    <?php } ?>
  </table>

  <!-- Formulir Tambah Kostum (Modal) -->
  <div id="addModal" style="display: none;">
    <h2>Add Costume</h2>
    <form id="addForm" method="POST" action="">
      <input type="text" name="category_id" placeholder="Category">
      <input type="text" name="costume_name" placeholder="Costume Name">
      <input type="text" name="description" placeholder="Description">
      <input type="text" name="price" placeholder="Price">
      <input type="text" name="stok" placeholder="Stock">
      <button type="submit" name="add_submit">Add</button>
    </form>
  </div>

  <!-- Formulir Edit Kostum (Modal) -->
  <div id="editModal" style="display: none;">
    <h2>Edit Costume</h2>
    <form id="editForm" method="POST" action="">
      <input type="hidden" name="costume_id" id="edit_costume_id">
      <input type="text" name="edit_category_id" id="edit_category_id" placeholder="Category">
      <input type="text" name="edit_costume_name" id="edit_costume_name" placeholder="Costume Name">
      <input type="text" name="edit_description" id="edit_description" placeholder="Description">
      <input type="text" name="edit_price" id="edit_price" placeholder="Price">
      <input type="text" name="edit_stok" id="edit_stok" placeholder="Stock">
      <button type="submit" name="edit_submit">Save</button>
    </form>
  </div>

  <button onclick="showAddModal()">Add Costume</button>

  <script>
    // Fungsi untuk menampilkan modal tambah kostum
    function showAddModal() {
      document.getElementById("addModal").style.display = "block";
    }

    // Fungsi untuk mengisi formulir edit kostum dengan data yang sudah ada
    function editCostume(costumeID) {
      // Mengambil elemen-elemen formulir
      var editForm = document.getElementById("editForm");
      var editCostumeID = document.getElementById("edit_costume_id");
      var editCategoryID = document.getElementById("edit_category_id");
      var editCostumeName = document.getElementById("edit_costume_name");
      var editDescription = document.getElementById("edit_description");
      var editPrice = document.getElementById("edit_price");
      var editStok = document.getElementById("edit_stok");

      // Mengisi nilai-nilai formulir dengan data kostum yang akan diedit
      editCostumeID.value = costumeID;
      editCategoryID.value = "<?php echo $row['category_id']; ?>";
      editCostumeName.value = "<?php echo $row['costume_name']; ?>";
      editDescription.value = "<?php echo $row['description']; ?>";
      editPrice.value = "<?php echo $row['price']; ?>";
      editStok.value = "<?php echo $row['stok']; ?>";

      // Menampilkan modal edit
      document.getElementById("editModal").style.display = "block";
    }
  </script>
</body>
</html>
