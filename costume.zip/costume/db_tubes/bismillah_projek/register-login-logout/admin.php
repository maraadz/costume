<?php
session_start();

// Cek apakah pengguna telah login dan memiliki peran admin
if (!isset($_SESSION['user_id']) || $_SESSION['role_id'] != 1) {
  header('Location: index.php');
  exit;
}

// Fungsi untuk mendapatkan jumlah data dari tabel tertentu
function getCount($conn, $table) {
  $query = "SELECT COUNT(*) AS count FROM $table";
  $result = mysqli_query($conn, $query);
  $count = mysqli_fetch_assoc($result)['count'];
  return $count;
}

// Memasukkan file koneksi database
include 'connection.php';
?>

<!DOCTYPE html>
<html>
<head>
  <title>Welcome to Shinju Rent Cosplay - Admin</title>
  <style>
    /* CSS code for navbar (added) */
    .navbar {
      background-color: #f2f2f2;
      overflow: hidden;
      text-align: center;
    }

    .navbar a {
      display: inline-block;
      color: #000;
      padding: 14px 16px;
      text-decoration: none;
      font-size: 18px;
      transition: background-color 0.3s;
    }

    .navbar a:hover {
      background-color: #e0e0e0;
    }

    /* Rest of the CSS code (updated) */
    body {
      font-family: Arial, sans-serif;
      background: linear-gradient(45deg, #ff9eeb, #a6dced, #cfa1ff);
      margin: 0;
      padding: 0;
    }

    .header {
      background: linear-gradient(to bottom, #333, #222);
      padding: 20px;
      color: #fff;
      text-align: center;
    }

    h1 {
      margin: 0;
      font-size: 36px;
      text-align: center;
      padding: 20px;
      color: #fff;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
    }

    .main {
      max-width: 1200px;
      margin: 20px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      text-align: center;
    }

    .admin-feature {
      display: flex;
      justify-content: center;
      align-items: center;
      margin-bottom: 20px;
    }

    .admin-feature a {
      display: block;
      width: 200px;
      height: 150px;
      background-color: #f2f2f2;
      color: #000;
      padding: 20px;
      text-decoration: none;
      font-size: 18px;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      transition: background-color 0.3s;
    }

    .admin-feature a:hover {
      background-color: #e0e0e0;
    }
  </style>
</head>
<body>
  <h1>Welcome to Shinju Rent Cosplay - Admin</h1>
  <div class="navbar">
    <a href="index.php">Home</a>
    <a href="admin_addresses.php">Check Addresses</a>
<a href="admin_categories.php">Check Categories</a>
<a href="admin_costumes.php">Check Costumes</a>
<a href="admin_orders.php">Check Orders</a>
<a href="admin_payments.php">Check Payments</a>
<a href="admin_reviews.php">Check Reviews</a>
<a href="logout.php">Logout</a>

  </div>
  <div class="main">
    <div class="admin-feature">
      <a href="admin_addresses.php">Check Addresses</a>
      <a href="admin_categories.php">Check Categories</a>
      <a href="admin_costumes.php">Check Costumes</a>
      <a href="admin_orders.php">Check Orders</a>
    </div>
    <div class="admin-feature">
      <a href="admin_payments.php">Check Payments</a>
      <a href="admin_reviews.php">Check Reviews</a>
    </div>
  </div>
</body>
</html>
