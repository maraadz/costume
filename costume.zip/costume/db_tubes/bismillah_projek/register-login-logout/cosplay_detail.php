<!DOCTYPE html>
<html>
<head>
  <title>Halaman Detail Cosplay</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <script src="script.js"></script>
  <style>
    /* Kode CSS untuk bagian detail cosplay */
    .cosplay-detail {
      max-width: 1200px;
      margin: 20px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      text-align: center;
    }

    .cosplay-image {
      max-width: 400px;
      height: auto;
      margin-bottom: 20px;
    }

    .cosplay-title {
      font-size: 24px;
      margin-bottom: 10px;
    }

    .cosplay-description {
      color: #666;
      margin-bottom: 20px;
    }

    .cosplay-price {
      font-size: 18px;
      margin-bottom: 10px;
    }

    .cosplay-stock {
      color: #666;
      margin-bottom: 20px;
    }

    .cosplay-reviews {
      margin-bottom: 20px;
    }

    .cosplay-reviews h3 {
      font-size: 18px;
      margin-bottom: 10px;
    }

    .cosplay-reviews p {
      color: #666;
      font-size: 14px;
    }
  </style>
</head>
<body>
  <h2>Halaman Detail Cosplay</h2>
  <div class="cosplay-detail">
    <?php
    // Koneksi ke database
    $host = 'nama_host_anda';
    $username = 'nama_pengguna_anda';
    $password = 'kata_sandi_anda';
    $database = 'nama_database_anda';

    $conn = new mysqli($host, $username, $password, $database);

    // Periksa koneksi
    if ($conn->connect_error) {
      die("Koneksi gagal: " . $conn->connect_error);
    }

    // Ambil detail cosplay dari database
    $cosplayId = $_GET['id']; // Anda mengirimkan ID cosplay melalui URL
    $sql = "SELECT * FROM costumes WHERE id = $cosplayId";
    $result = $conn->query($sql);

    // Tampilkan detail cosplay
    if ($result->num_rows > 0) {
      $row = $result->fetch_assoc();
      echo '<img src="' . $row['image'] . '" alt="Gambar Cosplay" class="cosplay-image">';
      echo '<h3 class="cosplay-title">' . $row['title'] . '</h3>';
      echo '<p class="cosplay-description">' . $row['description'] . '</p>';
      echo '<p class="cosplay-price">Harga: ' . $row['price'] . '</p>';
      echo '<p class="cosplay-stock">Stok: ' . $row['stock'] . '</p>';

      // Tampilkan ulasan cosplay
      echo '<div class="cosplay-reviews">';
      echo '<h3>Ulasan</h3>';

// Ambil ulasan dari database (asumsikan tabel ulasan bernama "reviews")
$reviewsSql = "SELECT * FROM reviews WHERE cosplay_id = $cosplayId";
$reviewsResult = $conn->query($reviewsSql);

if ($reviewsResult->num_rows > 0) {
  while ($reviewRow = $reviewsResult->fetch_assoc()) {
    echo '<p>' . $reviewRow['review'] . '</p>';
  }
} else {
  echo '<p>Tidak ada ulasan saat ini.</p>';
}

echo '</div>'; // Tutup div cosplay-reviews

echo '</div>'; // Tutup div cosplay-detail

// Tutup koneksi database
$conn->close();
?>
</body>
</html>
