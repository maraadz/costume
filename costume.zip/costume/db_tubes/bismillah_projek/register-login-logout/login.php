<?php
// Set session untuk pengguna yang berhasil login
$_SESSION['user_id'] = $user_id; // Ganti dengan variabel yang sesuai untuk menyimpan ID pengguna
$_SESSION['role_id'] = $role_id; // Ganti dengan variabel yang sesuai untuk menyimpan ID peran

?>
<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link rel="stylesheet" type="text/css" href="bootstrap.min.css">
  <script src="jquery.min.js"></script>
  <script src="bootstrap.min.js"></script>
</head>
<body>
  <div class="container">
    <h2>Login</h2>
    <form method="POST" action="login_process.php">
      <div class="form-group">
        <label for="username">Username</label>
        <input type="text" class="form-control" id="username" name="username" required>
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" class="form-control" id="password" name="password" required>
      </div>
      <button type="submit" class="btn btn-primary">Login</button>
    </form>
    <p>Don't have an account? <a href="register.php">Register now</a></p>
  </div>
</body>
</html>
