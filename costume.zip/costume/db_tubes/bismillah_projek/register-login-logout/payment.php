<?php
session_start();
include "connection.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Payment</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="script.js"></script>
</head>
<body>
<?php
// Cek apakah pengguna sudah login atau belum
// Jika belum, alihkan ke halaman login
if (!isset($_SESSION['user_id'])) {
  header("Location: form_login.php");
  exit();
}

// Cek apakah ada category_id yang dikirimkan
// Jika tidak, alihkan kembali ke halaman customes
if (!isset($_GET['category_id'])) {
  header("Location: customes.php");
  exit();
}

// Ambil category_id dari parameter URL
$category_id = $_GET['category_id'];

// Ambil informasi custom cosplay berdasarkan category_id (asumsikan tabel customes bernama "customes")
$customesSql = "SELECT * FROM customes WHERE category_id = $category_id";
$customesResult = $conn->query($customesSql);

if ($customesResult->num_rows > 0) {
  $customesRow = $customesResult->fetch_assoc();
  $customesId = $customesRow['customes_id'];
  $customesName = $customesRow['customes_name'];
  $customesPrice = $customesRow['customes_price'];
  $customesImage = $customesRow['customes_image'];

  // Tampilkan form order
  echo '<h2>Order Cosplay: ' . $customesName . '</h2>';
  echo '<div class="order-details">';
  echo '<img src="' . $customesImage . '" alt="' . $customesName . '" class="customes-image">';
  echo '<h3>Harga: $' . $customesPrice . '</h3>';
  echo '<form action="payment.php?category_id=' . $category_id . '" method="POST">';
  echo '<label for="address">Alamat:</label>';
  echo '<input type="text" name="address" id="address">';
  echo '<input type="hidden" name="customes_id" value="' . $customesId . '">';
  echo '<input type="hidden" name="customes_name" value="' . $customesName . '">';
  echo '<input type="hidden" name="customes_price" value="' . $customesPrice . '">';
  echo '<input type="submit" name="submit" value="Order Now">';
  echo '</form>';
  echo '<a href="customes.php">Cancel</a>';
  echo '</div>'; // Tutup div order-details

  // Cek apakah ada data yang dikirimkan melalui form order
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form order
    $customesId = $_POST['customes_id'];
    $customesName = $_POST['customes_name'];
    $customesPrice = $_POST['customes_price'];
    $address = $_POST['address'];

    // Insert data ke tabel orders
    $orderSql = "INSERT INTO orders (user_id, customes_id) VALUES ('$_SESSION[user_id]', '$customesId')";
    $conn->query($orderSql);
    $orderId = $conn->insert_id;

    // Insert data ke tabel addresses
    $addressSql = "INSERT INTO addresses (address) VALUES ('$address')";
    $conn->query($addressSql);
    $addressId = $conn->insert_id;

    // Insert data ke tabel payment
    $paymentDate = date('Y-m-d H:i:s');
    $amount = $customesPrice;
    $paymentSql = "INSERT INTO payment (order_id, payment_date, amount, address_id) VALUES ('$orderId', '$paymentDate', '$amount', '$addressId')";
    $conn->query($paymentSql);

    echo '<p>Pembayaran berhasil.</p>';
    echo '<p>Terima kasih telah melakukan order cosplay. Pesanan Anda sedang diproses.</p>';
  }
}
?>

</body>
</html>