<!DOCTYPE html>
<html>
<head>
    <title>Ulasan dan Penilaian</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="script.js"></script>
</head>
<body>
    <h2>Ulasan dan Penilaian</h2>
    <!-- Review and rating section here -->
</body>
</html>
