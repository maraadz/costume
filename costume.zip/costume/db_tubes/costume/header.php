<!doctype html>
<html lang="en">
  <head>
  
    <title>Tugas UAS 2023 Teknik Informatika UIN Malang</title>
	
    <meta charset="utf-8">
	
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
    <meta name="description" content="">
    <meta name="author" content="Template">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">

   
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/template.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/lightbox.css">
    
	
    <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
    
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	
  </head>
  <body>

  

  

	  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky">
  
  		
    <div class="jumbotron pt-4 pb-4">
        <div class="row">
            <div class="col-sm-8 bg-transparent text-white">
                 <h2><b style="text-transform:uppercase;"><?= $info_web->nama_rental;?> </b></h2>
            </div>
            <div class="col-sm-4">
                <form class="form-inline" method="get" action="blog.php">
                    <input class="form-control mr-sm-2" type="search" name="cari" placeholder="Cari Nama Costume" aria-label="Search">
                    <button class="btn btn-secondary" type="submit">Search</button>
                </form>
            </div>
        </div>
    </div>
			
			
  
        <div class="container">
	    
          <div class="row">	  
	  		  			  
			<div class="col-12"><br/>
							
			 <nav class="main-nav">
						
                <!-- ***** Menu Start ***** -->
             <ul class="nav">
                  <li class="scroll-to-section">
                   	<a href="index.php" class="active">Home<span class="sr-only"></span></a></li>
                  </li>
                  <li class="scroll-to-section">
                    <a href="blog.php">Daftar costume</a>
                  </li>
                  <li class="scroll-to-section">
                    <a href="kontak.php">Kontak Kami</a>
                  </li>
                     <?php if(!empty($_SESSION['USER'])){?>
                  <li class="scroll-to-section">
                    <a href="history.php">History</a>
                  </li>
                  <li class="scroll-to-section">
                    <a href="profil.php">Profil</a>
                  </li>
                <?php }?>
            </ul>
			

			
                <?php if(!empty($_SESSION['USER'])){?>
            <ul class="navbar-nav my-2 my-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="#">
                        <i class="fa fa-user"> </i> Hallo, <?php echo $_SESSION['USER']['nama_pengguna'];?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" onclick="return confirm('Apakah anda ingin logout ?');" href="<?php echo $url;?>admin/logout.php">Logout</a>
                </li>
            </ul>
                <?php }?>
				
                      <a class='menu-trigger'>
                          <span>Menu</span>
                      </a>
                      <!-- ***** Menu End ***** -->
                  </nav>
              </div>
          </div>
      </div>
  </header>
  <!-- ***** Header Area End ***** -->
  
    <!-- ***** Main Banner Area Start ***** -->
  <section class="section main-banner" id="top" data-section="section1">
      <video autoplay muted loop id="bg-video">
          <source src="assets/images/Sequence.mp4" type="video/mp4" />
      </video>

      <div class="video-overlay header-text">
          <div class="container">
            <div class="row">
              <div class="col-lg-12">

               <div class="caption">
                   <h6>Hello Pelanggan</h6>
                   <h2>Selamat Datang Di</h2>
                   <p>Rental Costume Anime Tugas UAS 2023 Teknik Informatika UIN Malang</p>
               </div>
			   
              </div>
            </div>
          </div>
      </div>
  </section>
  <!-- ***** Main Banner Area End ***** -->