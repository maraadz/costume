<?php

 require '../../koneksi/koneksi.php';

if($_GET['id'] == 'konfirmasi')
{
    $data2[] = $_POST['status'];
    $data2[] = $_POST['id_costume'];
    $sql2 = "UPDATE `costume` SET `status`= ? WHERE id_costume= ?";
    $row2 = $koneksi->prepare($sql2);
    $row2->execute($data2);

    echo '<script>alert("Status costume di pinjam");history.go(-1);</script>'; 
}