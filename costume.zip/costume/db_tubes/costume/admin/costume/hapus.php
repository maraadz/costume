<?php

    //koneksi ke database
    $koneksi = mysqli_connect('localhost', 'root', '', 'costumedb');

    // melakukan perulangan sebanyak data yang ingin dihapus
    for($i=0; $i<=count($_POST['hapus'])-1; $i++){
        //menghapus data sesuai urutan array
        mysqli_query($koneksi, 'delete from costume where id_costume ='.$_POST['hapus'][$i]);
    }

    //kembali ke halaman sebelumnya
    header("Location: ceklist.php");
    die();


?>