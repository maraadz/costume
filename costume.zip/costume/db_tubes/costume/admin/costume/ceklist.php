<?php

    require '../../koneksi/koneksi.php';
    $title_web = 'Daftar costume';
    include '../header.php';
    if(empty($_SESSION['USER']))
    {
        session_start();
    }
?>
    

    
    <body>
        <div class="container">

          
			<br/>
            <form action="hapus.php" method="post">
                
				<div class="card-header text-white bg-primary">
                      <h4 class="card-title">
                       Cek List Data Costume
                        </h4>
		             <div class="float-right">  
                          <a href="ceklist.php" class="btn btn-success">Uncek Data Terpilih</a>
                          <button class="btn btn-danger" type="submit">Hapus</button>
				     </div>
			     </div>	
				
				<br><br>
			<div class="card-body">	
                <div class="table-responsive">
                  <table class="table table-bordered">
                    
					<thead>
                        <tr>
                            <th>No</th>
                            <th>No produk</th>
                            <th>Merk</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            // koneksi ke database
                            $koneksi = mysqli_connect('localhost', 'root', '', 'costumedb');
                            // mengambil data dari tabel mahasiswa 
                            $select = mysqli_query($koneksi, "select * from costume");
    
                            //membuat variabell index penomoran
                            $no = 1;
    
                            //melakukan perualangan data dengan while
                            while($data= mysqli_fetch_array($select)){
                        ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo $data['no_produk']; ?></td>
                            <td><?php echo $data['merk']; ?></td>
                            <td><?php echo $data['status']; ?></td>
                            <td width="20px">
                            <!-- membuat checkbox dengan name="hapus[]" tanda [] digunakan untuk menampung banyak data  -->
                                <input type="checkbox" name="hapus[]" value="<?php echo $data['id_costume']; ?>">
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                   </table>
				  </div>
				</div>
              </form>
			
        </div>
    
        <!-- jquery datatable -->
        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js">
        </script>
    
        <!-- fungsi datatable -->
        <script>
            $(document).ready(function () {
                $('#table_id').DataTable();
            });
    
        </script>
		
	<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

?>



		
    </body>
<?php  include '../footer.php';?>